// Custom JS goes here ------------
<!-- start TEAM SLIDING EFFECT -->
<script>
// toggle staff content on click by geno quiroz
$(document).ready(function(){
    $('.gq_img1, .gq_name1').click( function() {
        $(".gq_info1").toggleClass("gq_unhide_info");
        $(".gq_name1").toggleClass("gq_hover_name");
        $(".gq_img1").toggleClass("gq_close_icon");
    });
    $('.gq_img2, .gq_name2').click( function() {
        $(".gq_info2").toggleClass("gq_unhide_info");
        $(".gq_name2").toggleClass("gq_hover_name");
        $(".gq_img2").toggleClass("gq_close_icon");
    });
    $('.gq_img3, .gq_name3').click( function() {
        $(".gq_info3").toggleClass("gq_unhide_info");
        $(".gq_name3").toggleClass("gq_hover_name");
        $(".gq_img3").toggleClass("gq_close_icon");
    });
    $('.gq_img4, .gq_name4').click( function() {
        $(".gq_info4").toggleClass("gq_unhide_info");
        $(".gq_name4").toggleClass("gq_hover_name");
        $(".gq_img4").toggleClass("gq_close_icon");
    });
});
</script><!-- end TEAM SLIDING EFFECT -->
