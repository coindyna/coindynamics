# divi-flipping-blurb
Get your Divi Blurb to Flip
Intended to be used in Divi Child Theme. 
Needs to be put in side child theme/custom-modules. The functions.php needs to be added to your own functions.php file.
